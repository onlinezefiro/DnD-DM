# D&D Campaign Manager

## Overview

This is a full-stack D&D (Dungeons & Dragons) campaign management application that allows players to create characters and engage in AI-powered dungeon master sessions. The application features a React frontend with a modern UI built using shadcn/ui components, an Express.js backend API, and PostgreSQL database integration through Drizzle ORM.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with a custom D&D-themed color palette
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Style**: REST API with JSON responses
- **Database**: PostgreSQL with persistent storage
- **Database ORM**: Drizzle ORM with Neon serverless PostgreSQL
- **External Services**: OpenAI API for AI dungeon master responses

### Database Design
- **Primary Database**: PostgreSQL with persistent storage (configured via Neon Database serverless)
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Storage Layer**: DatabaseStorage class replacing in-memory storage for production persistence
- **Tables**:
  - `characters`: Player character data including stats, equipment, and inventory
  - `game_sessions`: Campaign sessions linked to characters
  - `messages`: Chat history between players and AI dungeon master
- **Relations**: Proper foreign key relationships between characters, sessions, and messages

## Key Components

### Character Management
- **Character Creation**: Full D&D 5e character creation with ability score rolling
- **Character Sheet**: Comprehensive character display with stats, equipment, and inventory
- **Mobile-Responsive**: Adaptive layout with mobile drawer for character information

### AI Dungeon Master
- **OpenAI Integration**: GPT-4 powered dungeon master for dynamic storytelling
- **Dice Rolling System**: Virtual dice roller with D&D standard dice types (d4, d6, d8, d10, d12, d20, d100)
- **Combat & Narrative**: AI generates responses for different action types (combat, exploration, social, narrative)

### Chat Interface
- **Real-time Messaging**: Player actions and DM responses in chat format
- **Action Classification**: Different message types for narrative, actions, and dice rolls
- **Session Management**: Persistent game sessions with message history

## Data Flow

1. **Character Creation**: User creates character → Validates data → Stores in database → Redirects to game
2. **Game Session**: Character loads → Creates/retrieves active session → Generates intro via OpenAI
3. **Player Action**: User inputs action → Sends to AI DM → Receives narrative response → Updates chat
4. **Dice Rolling**: User triggers dice roll → Generates random result → Optionally sends to AI for interpretation

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection
- **drizzle-orm**: Database ORM and query builder
- **openai**: OpenAI API client for AI dungeon master
- **@tanstack/react-query**: Server state management
- **express**: Backend web framework

### UI Dependencies
- **@radix-ui/***: Headless UI components for accessibility
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **clsx**: Conditional className utility

### Development Dependencies
- **vite**: Frontend build tool and dev server
- **tsx**: TypeScript execution for Node.js
- **esbuild**: JavaScript bundler for production builds

## Deployment Strategy

### Development
- **Frontend**: Vite dev server with HMR (Hot Module Replacement)
- **Backend**: tsx for TypeScript execution with auto-restart
- **Database**: Drizzle Kit for schema management and migrations

### Production Build
- **Frontend**: Vite builds to `dist/public` directory
- **Backend**: esbuild bundles server code to `dist/index.js`
- **Static Serving**: Express serves built frontend in production mode
- **Database**: Environment-based DATABASE_URL configuration

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string (required)
- **OPENAI_API_KEY**: OpenAI API authentication (required for AI features)
- **NODE_ENV**: Environment mode (development/production)

## Changelog
- July 05, 2025. Initial setup
- July 05, 2025. Fixed character retrieval issue - added missing GET /api/characters route and getAllCharacters() storage method
- July 05, 2025. Added PostgreSQL database integration - replaced in-memory storage with persistent DatabaseStorage, added database relations, and deployed schema successfully

## User Preferences
Preferred communication style: Simple, everyday language.