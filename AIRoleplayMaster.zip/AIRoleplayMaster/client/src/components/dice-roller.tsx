import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dice1, Dice2, Dice3, Dice4, Dice5, Dice6 } from "lucide-react";

interface DiceRollerProps {
  isOpen: boolean;
  onClose: () => void;
  onRoll: (result: { type: string; roll: number; modifier: number; total: number }) => void;
}

const diceTypes = [
  { type: "d4", icon: Dice1, max: 4 },
  { type: "d6", icon: Dice2, max: 6 },
  { type: "d8", icon: Dice3, max: 8 },
  { type: "d10", icon: Dice4, max: 10 },
  { type: "d12", icon: Dice5, max: 12 },
  { type: "d20", icon: Dice6, max: 20 },
  { type: "d100", icon: Dice6, max: 100 },
];

export default function DiceRoller({ isOpen, onClose, onRoll }: DiceRollerProps) {
  const [selectedDice, setSelectedDice] = useState("d20");
  const [modifier, setModifier] = useState(0);
  const [lastRoll, setLastRoll] = useState<{ roll: number; total: number } | null>(null);

  const rollDice = () => {
    const diceType = diceTypes.find(d => d.type === selectedDice);
    if (!diceType) return;

    const roll = Math.floor(Math.random() * diceType.max) + 1;
    const total = roll + modifier;

    const result = {
      type: selectedDice,
      roll,
      modifier,
      total,
    };

    setLastRoll({ roll, total });
    onRoll(result);

    // Auto-close after a brief delay to show result
    setTimeout(() => {
      onClose();
      setLastRoll(null);
    }, 2000);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-dm-surface border-dm-slate max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-cinzel font-semibold text-dm-gold">
            Roll Dice
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Dice Selection */}
          <div>
            <Label className="block text-sm font-medium text-dm-text mb-3">Select Dice Type</Label>
            <div className="grid grid-cols-4 gap-2">
              {diceTypes.map(({ type, icon: Icon }) => (
                <Button
                  key={type}
                  onClick={() => setSelectedDice(type)}
                  variant={selectedDice === type ? "default" : "outline"}
                  className={`h-16 flex flex-col items-center justify-center ${
                    selectedDice === type
                      ? "bg-dm-purple hover:bg-purple-600 text-white"
                      : "bg-dm-charcoal hover:bg-dm-slate border-dm-slate text-dm-text"
                  }`}
                >
                  <Icon className="w-6 h-6 mb-1" />
                  <span className="text-xs">{type}</span>
                </Button>
              ))}
            </div>
          </div>

          {/* Modifier Input */}
          <div>
            <Label htmlFor="modifier" className="block text-sm font-medium text-dm-text mb-2">
              Modifier
            </Label>
            <Input
              id="modifier"
              type="number"
              value={modifier}
              onChange={(e) => setModifier(parseInt(e.target.value) || 0)}
              className="bg-dm-charcoal border-dm-slate text-dm-text"
              placeholder="0"
            />
          </div>

          {/* Roll Result Display */}
          {lastRoll && (
            <div className="bg-dm-charcoal rounded-lg p-4 text-center animate-fade-in">
              <div className="text-3xl font-mono font-bold text-dm-gold mb-2 animate-dice-roll">
                {lastRoll.total}
              </div>
              <div className="text-sm text-gray-400">
                {selectedDice}: {lastRoll.roll}{modifier !== 0 ? ` + ${modifier}` : ''}
              </div>
            </div>
          )}

          {/* Roll Button */}
          <Button
            onClick={rollDice}
            className="w-full bg-dm-purple hover:bg-purple-600 text-white py-3"
            disabled={!!lastRoll}
          >
            <Dice1 className="w-4 h-4 mr-2" />
            {lastRoll ? "Rolling..." : "Roll Dice"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
