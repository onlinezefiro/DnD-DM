import { Progress } from "@/components/ui/progress";
import type { Character } from "@shared/schema";

interface CharacterSheetProps {
  character: Character;
}

function getModifier(score: number): number {
  return Math.floor((score - 10) / 2);
}

function formatModifier(modifier: number): string {
  return modifier >= 0 ? `+${modifier}` : `${modifier}`;
}

export default function CharacterSheet({ character }: CharacterSheetProps) {
  const hpPercentage = (character.hitPoints / character.maxHitPoints) * 100;

  return (
    <div className="overflow-y-auto scrollbar-thin h-full">
      <div className="p-6">
        {/* Character Header */}
        <div className="text-center mb-6">
          <div className="w-20 h-20 bg-dm-gold rounded-full mx-auto mb-3 flex items-center justify-center">
            <span className="text-2xl font-bold text-dm-charcoal">
              {character.name ? (
                character.name.charAt(0) + (character.name.split(' ')[1]?.charAt(0) || character.name.charAt(1) || '')
              ) : '?'}
            </span>
          </div>
          <h2 className="text-xl font-cinzel font-semibold text-dm-gold">{character.name}</h2>
          <p className="text-gray-400 capitalize">{character.race} {character.class}</p>
          <p className="text-sm text-gray-500">Level {character.level}</p>
        </div>

        {/* Health and Resources */}
        <div className="space-y-4 mb-6">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span>Hit Points</span>
              <span className="font-mono">{character.hitPoints}/{character.maxHitPoints}</span>
            </div>
            <Progress value={hpPercentage} className="h-3" />
          </div>
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span>Armor Class</span>
              <span className="font-mono text-dm-gold">{character.armorClass}</span>
            </div>
          </div>
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span>Speed</span>
              <span className="font-mono">{character.speed} ft</span>
            </div>
          </div>
        </div>

        {/* Ability Scores */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-dm-gold mb-3">Ability Scores</h3>
          <div className="grid grid-cols-2 gap-3">
            {[
              { key: 'strength', label: 'STR' },
              { key: 'dexterity', label: 'DEX' },
              { key: 'constitution', label: 'CON' },
              { key: 'intelligence', label: 'INT' },
              { key: 'wisdom', label: 'WIS' },
              { key: 'charisma', label: 'CHA' }
            ].map(({ key, label }) => {
              const score = character[key as keyof Character] as number;
              const modifier = getModifier(score);
              const isHighStat = score >= 14;
              
              return (
                <div key={key} className="bg-dm-charcoal rounded-lg p-3 text-center">
                  <div className="text-xs text-gray-400 uppercase">{label}</div>
                  <div className={`text-lg font-mono font-bold ${isHighStat ? 'text-dm-emerald' : ''}`}>
                    {score}
                  </div>
                  <div className="text-xs text-gray-400">{formatModifier(modifier)}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Skills */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-dm-gold mb-3">Skills</h3>
          <div className="space-y-2">
            {Object.entries(character.skills).map(([skill, bonus]) => (
              <div key={skill} className="flex justify-between text-sm">
                <span className="capitalize">{skill}</span>
                <span className="font-mono text-dm-emerald">{formatModifier(bonus)}</span>
              </div>
            ))}
            {Object.keys(character.skills).length === 0 && (
              <p className="text-gray-400 text-sm">No special skills trained</p>
            )}
          </div>
        </div>

        {/* Equipment */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-dm-gold mb-3">Equipment</h3>
          <div className="space-y-2">
            {character.equipment && character.equipment.length > 0 ? character.equipment.map((item, index) => (
              <div key={index} className="flex items-center justify-between bg-dm-charcoal rounded-lg p-2">
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${item.equipped ? 'bg-dm-emerald' : 'bg-gray-500'}`} />
                  <span className="text-sm">{item.name}</span>
                </div>
                <span className="text-xs text-gray-400 capitalize">{item.type}</span>
              </div>
            )) : (
              <div className="text-sm text-gray-400 text-center py-4">No equipment</div>
            )}
          </div>
        </div>

        {/* Inventory */}
        <div>
          <h3 className="text-lg font-semibold text-dm-gold mb-3">Inventory</h3>
          <div className="space-y-2">
            {character.inventory && character.inventory.length > 0 ? character.inventory.map((item, index) => (
              <div key={index} className="flex items-center justify-between bg-dm-charcoal rounded-lg p-2">
                <div className="flex items-center space-x-2">
                  <span className="text-sm">{item.name}</span>
                </div>
                <span className="text-xs text-gray-400">x{item.quantity}</span>
              </div>
            )) : (
              <div className="text-sm text-gray-400 text-center py-2">No items in inventory</div>
            )}
            <div className="flex items-center justify-between bg-dm-charcoal rounded-lg p-2">
              <div className="flex items-center space-x-2">
                <span className="text-sm">Gold Pieces</span>
              </div>
              <span className="text-xs text-dm-gold">{character.goldPieces || 0}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
