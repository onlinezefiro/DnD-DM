import { useState, useEffect, useRef } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Send, Dice1, Search, Sword, Shield, Sparkles, UserX } from "lucide-react";
import DiceRoller from "./dice-roller";
import type { Character, GameSession, Message } from "@shared/schema";

interface ChatInterfaceProps {
  character: Character;
  activeSession: GameSession | null;
}

interface DMResponse {
  narrative: string;
  diceRolls?: Array<{
    type: string;
    roll: number;
    modifier: number;
    total: number;
    description: string;
  }>;
  requiresPlayerInput: boolean;
  actionType: string;
}

export default function ChatInterface({ character, activeSession }: ChatInterfaceProps) {
  const [playerInput, setPlayerInput] = useState("");
  const [showDiceRoller, setShowDiceRoller] = useState(false);
  const [currentSession, setCurrentSession] = useState<GameSession | null>(activeSession);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get or create game session
  const createSessionMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/sessions", {
        characterId: Number(character.id),
        title: `${character.name || "Unknown Character"}'s Adventure`,
      });
      return response.json();
    },
    onSuccess: (session) => {
      setCurrentSession(session);
      // Generate game intro
      generateIntroMutation.mutate();
    },
  });

  // Generate game introduction
  const generateIntroMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/game-intro", {
        characterName: character.name,
        characterClass: character.class,
        characterRace: character.race,
      });
      return response.json();
    },
    onSuccess: (data) => {
      if (currentSession) {
        createMessageMutation.mutate({
          sessionId: currentSession.id,
          sender: "dm",
          content: data.intro,
          messageType: "narrative",
        });
      }
    },
  });

  // Get messages for current session
  const { data: messages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ["/api/sessions", currentSession?.id, "messages"],
    enabled: !!currentSession,
  });

  // Create message mutation
  const createMessageMutation = useMutation({
    mutationFn: async (messageData: { sessionId: number; sender: string; content: string; messageType: string; diceRoll?: any }) => {
      const response = await apiRequest("POST", `/api/sessions/${messageData.sessionId}/messages`, messageData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions", currentSession?.id, "messages"] });
    },
  });

  // DM response mutation
  const dmResponseMutation = useMutation({
    mutationFn: async (playerAction: string) => {
      const response = await apiRequest("POST", "/api/dm-response", {
        playerAction,
        sessionId: currentSession?.id,
      });
      return response.json();
    },
    onSuccess: (dmResponse: DMResponse) => {
      if (currentSession) {
        createMessageMutation.mutate({
          sessionId: currentSession.id,
          sender: "dm",
          content: dmResponse.narrative,
          messageType: dmResponse.actionType,
          diceRoll: dmResponse.diceRolls?.[0] || null,
        });
      }
    },
    onError: (error) => {
      toast({
        title: "DM Response Failed",
        description: "The DM seems to be taking a short rest. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Initialize session if none exists
  useEffect(() => {
    if (!activeSession && !currentSession) {
      createSessionMutation.mutate();
    } else if (activeSession && !currentSession) {
      setCurrentSession(activeSession);
    }
  }, [activeSession, currentSession]);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = () => {
    if (!playerInput.trim() || !currentSession) return;

    // Create player message
    createMessageMutation.mutate({
      sessionId: currentSession.id,
      sender: "player",
      content: playerInput,
      messageType: "action",
    });

    // Get DM response
    dmResponseMutation.mutate(playerInput);

    setPlayerInput("");
  };

  const handleQuickAction = (action: string) => {
    const templates = {
      investigate: "I carefully investigate the area, looking for clues or hidden details.",
      attack: "I ready my weapon and attack the nearest enemy.",
      defend: "I take a defensive stance, preparing to block incoming attacks.",
      cast: "I begin casting a spell...",
      stealth: "I attempt to move silently and remain hidden.",
    };
    setPlayerInput(templates[action as keyof typeof templates] || "");
  };

  const handleDiceRoll = (result: { type: string; roll: number; modifier: number; total: number }) => {
    if (currentSession) {
      createMessageMutation.mutate({
        sessionId: currentSession.id,
        sender: "player",
        content: `Rolled ${result.type}: ${result.total}`,
        messageType: "dice_roll",
        diceRoll: { ...result, description: `${result.type} roll` },
      });
    }
  };

  if (!currentSession) {
    return (
      <div className="flex-1 flex items-center justify-center bg-dm-charcoal">
        <div className="text-center">
          <div className="w-12 h-12 bg-dm-purple rounded-full mx-auto mb-4 flex items-center justify-center animate-pulse">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <p className="text-dm-text">Preparing your adventure...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-dm-charcoal">
      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto scrollbar-thin p-6 space-y-4">
        {messagesLoading ? (
          <div className="flex items-center justify-center h-32">
            <div className="text-center">
              <div className="w-8 h-8 bg-dm-purple rounded-full mx-auto mb-2 animate-pulse"></div>
              <p className="text-gray-400">Loading messages...</p>
            </div>
          </div>
        ) : (
          messages.map((message: Message) => (
            <div
              key={message.id}
              className={`flex items-start space-x-3 animate-fade-in ${
                message.sender === "player" ? "justify-end" : ""
              }`}
            >
              {message.sender === "dm" && (
                <div className="w-10 h-10 bg-dm-purple rounded-full flex items-center justify-center flex-shrink-0">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
              )}
              
              <div
                className={`rounded-lg p-4 max-w-2xl ${
                  message.sender === "dm"
                    ? "bg-dm-surface"
                    : "bg-dm-purple"
                }`}
              >
                <div className="flex items-center space-x-2 mb-2">
                  {message.sender === "player" && (
                    <span className="text-xs text-gray-300">
                      {message.timestamp.toLocaleTimeString()}
                    </span>
                  )}
                  <span className={`font-semibold ${
                    message.sender === "dm" ? "text-dm-gold" : "text-white"
                  }`}>
                    {message.sender === "dm" ? "Dungeon Master" : character.name}
                  </span>
                  {message.sender === "dm" && (
                    <span className="text-xs text-gray-400">
                      {message.timestamp.toLocaleTimeString()}
                    </span>
                  )}
                </div>

                {/* Dice roll display */}
                {message.diceRoll && (
                  <div className="bg-dm-slate rounded-lg p-3 mb-3 border-l-4 border-dm-emerald">
                    <div className="flex items-center space-x-2">
                      <Dice1 className="w-4 h-4 text-dm-emerald" />
                      <span className="text-sm font-mono text-dm-emerald">
                        {message.diceRoll.description}: {message.diceRoll.type} = {message.diceRoll.total}
                        {message.diceRoll.modifier !== 0 && ` (${message.diceRoll.roll} + ${message.diceRoll.modifier})`}
                      </span>
                    </div>
                  </div>
                )}

                <p className={`leading-relaxed ${
                  message.sender === "dm" ? "text-dm-text" : "text-white"
                }`}>
                  {message.content}
                </p>
              </div>

              {message.sender === "player" && (
                <div className="w-10 h-10 bg-dm-gold rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="font-bold text-dm-charcoal">
                    {character.name.charAt(0)}{character.name.split(' ')[1]?.charAt(0) || ''}
                  </span>
                </div>
              )}
            </div>
          ))
        )}

        {/* Loading indicator for DM response */}
        {dmResponseMutation.isPending && (
          <div className="flex items-start space-x-3 animate-fade-in">
            <div className="w-10 h-10 bg-dm-purple rounded-full flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div className="bg-dm-surface rounded-lg p-4 max-w-2xl">
              <div className="flex items-center space-x-2 mb-2">
                <span className="font-semibold text-dm-gold">Dungeon Master</span>
                <span className="text-xs text-gray-400">typing...</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-dm-purple rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-dm-purple rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
                  <div className="w-2 h-2 bg-dm-purple rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                </div>
                <span className="text-gray-400 text-sm">The DM is weaving your story...</span>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="border-t border-dm-slate bg-dm-surface p-6">
        <div className="flex space-x-4">
          <div className="flex-1">
            <Textarea
              value={playerInput}
              onChange={(e) => setPlayerInput(e.target.value)}
              className="w-full bg-dm-charcoal border-dm-slate text-dm-text placeholder-gray-400 resize-none focus:border-dm-purple"
              rows={3}
              placeholder="Describe your action or dialogue..."
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
            />
          </div>
          <div className="flex flex-col space-y-2">
            <Button
              onClick={handleSendMessage}
              disabled={!playerInput.trim() || createMessageMutation.isPending || dmResponseMutation.isPending}
              className="bg-dm-purple hover:bg-purple-600 text-white px-6 py-3"
            >
              <Send className="w-4 h-4 mr-2" />
              Send
            </Button>
            <Button
              onClick={() => setShowDiceRoller(true)}
              variant="outline"
              className="bg-dm-slate hover:bg-slate-600 text-dm-text border-dm-slate px-6 py-3"
            >
              <Dice1 className="w-4 h-4 mr-2" />
              Roll
            </Button>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex flex-wrap gap-2 mt-4">
          {[
            { key: "investigate", label: "Investigate", icon: Search },
            { key: "attack", label: "Attack", icon: Sword },
            { key: "defend", label: "Defend", icon: Shield },
            { key: "cast", label: "Cast Spell", icon: Sparkles },
            { key: "stealth", label: "Stealth", icon: UserX },
          ].map(({ key, label, icon: Icon }) => (
            <Button
              key={key}
              onClick={() => handleQuickAction(key)}
              variant="outline"
              size="sm"
              className="bg-dm-charcoal hover:bg-dm-slate border-dm-slate text-dm-text"
            >
              <Icon className="w-4 h-4 mr-1" />
              {label}
            </Button>
          ))}
        </div>
      </div>

      {/* Dice Roller Modal */}
      <DiceRoller
        isOpen={showDiceRoller}
        onClose={() => setShowDiceRoller(false)}
        onRoll={handleDiceRoll}
      />
    </div>
  );
}
