import { X } from "lucide-react";
import type { Character } from "@shared/schema";

interface MobileDrawerProps {
  character: Character;
}

function getModifier(score: number): number {
  return Math.floor((score - 10) / 2);
}

function formatModifier(modifier: number): string {
  return modifier >= 0 ? `+${modifier}` : `${modifier}`;
}

export default function MobileDrawer({ character }: MobileDrawerProps) {
  const closeMobileDrawer = () => {
    const drawer = document.getElementById('mobileCharacterDrawer');
    drawer?.classList.add('translate-y-full');
  };

  const hpPercentage = (character.hitPoints / character.maxHitPoints) * 100;

  return (
    <div
      id="mobileCharacterDrawer"
      className="fixed inset-x-0 bottom-0 bg-dm-surface border-t border-dm-slate z-40 transform translate-y-full transition-transform lg:hidden max-h-[80vh] overflow-y-auto"
    >
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-cinzel font-semibold text-dm-gold">Character Sheet</h3>
          <button
            onClick={closeMobileDrawer}
            className="text-gray-400 hover:text-dm-text transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        {/* Mobile Character Info (Condensed) */}
        <div className="space-y-4">
          {/* Character Basic Info */}
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-dm-gold rounded-full flex items-center justify-center">
              <span className="text-lg font-bold text-dm-charcoal">
                {character.name ? (
                  character.name.charAt(0) + (character.name.split(' ')[1]?.charAt(0) || character.name.charAt(1) || '')
                ) : '?'}
              </span>
            </div>
            <div className="flex-1">
              <h4 className="font-medium text-dm-gold">{character.name}</h4>
              <p className="text-sm text-gray-400 capitalize">{character.race} {character.class}</p>
              <p className="text-xs text-gray-500">Level {character.level}</p>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-sm text-gray-400">HP</div>
              <div className="font-mono text-lg">{character.hitPoints}/{character.maxHitPoints}</div>
              <div className="w-full bg-dm-charcoal rounded-full h-2 mt-1">
                <div 
                  className="bg-dm-emerald h-2 rounded-full" 
                  style={{ width: `${hpPercentage}%` }}
                ></div>
              </div>
            </div>
            <div className="text-center">
              <div className="text-sm text-gray-400">AC</div>
              <div className="font-mono text-lg text-dm-gold">{character.armorClass}</div>
            </div>
            <div className="text-center">
              <div className="text-sm text-gray-400">Speed</div>
              <div className="font-mono text-lg">{character.speed} ft</div>
            </div>
          </div>

          {/* Ability Scores */}
          <div>
            <h5 className="font-semibold text-dm-gold mb-2">Ability Scores</h5>
            <div className="grid grid-cols-3 gap-2">
              {[
                { key: 'strength', label: 'STR' },
                { key: 'dexterity', label: 'DEX' },
                { key: 'constitution', label: 'CON' },
                { key: 'intelligence', label: 'INT' },
                { key: 'wisdom', label: 'WIS' },
                { key: 'charisma', label: 'CHA' }
              ].map(({ key, label }) => {
                const score = character[key as keyof Character] as number;
                const modifier = getModifier(score);
                const isHighStat = score >= 14;
                
                return (
                  <div key={key} className="bg-dm-charcoal rounded p-2 text-center">
                    <div className="text-xs text-gray-400 uppercase">{label}</div>
                    <div className={`font-mono font-bold ${isHighStat ? 'text-dm-emerald' : ''}`}>
                      {score}
                    </div>
                    <div className="text-xs text-gray-400">{formatModifier(modifier)}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Equipment (Condensed) */}
          <div>
            <h5 className="font-semibold text-dm-gold mb-2">Equipment</h5>
            <div className="flex flex-wrap gap-1">
              {character.equipment ? character.equipment.filter(item => item.equipped).map((item, index) => (
                <span key={index} className="bg-dm-charcoal text-xs px-2 py-1 rounded">
                  {item.name}
                </span>
              )) : <span className="text-xs text-gray-400">No equipped items</span>}
            </div>
          </div>

          {/* Gold */}
          <div className="flex justify-between items-center bg-dm-charcoal rounded p-2">
            <span className="text-sm">Gold Pieces</span>
            <span className="font-mono text-dm-gold">{character.goldPieces || 0}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
