import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Crown, Dice6 } from "lucide-react";
import type { InsertCharacter } from "@shared/schema";

const races = [
  "Human", "Elf", "Dwarf", "Halfling", "Dragonborn", "Gnome", "Half-Elf", "Half-Orc", "Tiefling"
];

const classes = [
  "Barbarian", "Bard", "Cleric", "Druid", "Fighter", "Monk", "Paladin", "Ranger", "Rogue", "Sorcerer", "Warlock", "Wizard"
];

function rollStat(): number {
  // Roll 4d6, drop lowest
  const rolls = Array.from({ length: 4 }, () => Math.floor(Math.random() * 6) + 1);
  rolls.sort((a, b) => b - a);
  return rolls.slice(0, 3).reduce((sum, roll) => sum + roll, 0);
}

function getModifier(score: number): number {
  return Math.floor((score - 10) / 2);
}

export default function CharacterCreation() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [character, setCharacter] = useState<Partial<InsertCharacter>>({
    name: "",
    race: "",
    class: "",
    level: 1,
    strength: 10,
    dexterity: 10,
    constitution: 10,
    intelligence: 10,
    wisdom: 10,
    charisma: 10,
    skills: {},
    equipment: [
      { name: "Leather Armor", type: "armor", equipped: true },
      { name: "Shortsword", type: "weapon", equipped: true },
      { name: "Longbow", type: "weapon", equipped: true }
    ],
    inventory: [
      { name: "Healing Potion", quantity: 2, type: "consumable" },
      { name: "Ancient Map", quantity: 1, type: "misc" }
    ],
    goldPieces: 47
  });

  const createCharacterMutation = useMutation({
    mutationFn: async (data: InsertCharacter) => {
      const response = await apiRequest("POST", "/api/characters", data);
      return response.json();
    },
    onSuccess: (newCharacter) => {
      toast({
        title: "Character Created!",
        description: `${newCharacter.name} is ready for adventure.`,
      });
      setLocation(`/game/${newCharacter.id}`);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create character. Please try again.",
        variant: "destructive",
      });
    },
  });

  const rollStats = () => {
    const newStats = {
      strength: rollStat(),
      dexterity: rollStat(),
      constitution: rollStat(),
      intelligence: rollStat(),
      wisdom: rollStat(),
      charisma: rollStat(),
    };
    setCharacter(prev => ({ ...prev, ...newStats }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!character.name || !character.race || !character.class) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    const constitution = character.constitution || 10;
    const hitPoints = 10 + getModifier(constitution) + ((character.level || 1) - 1) * (6 + getModifier(constitution));
    
    const completeCharacter: InsertCharacter = {
      ...character as InsertCharacter,
      hitPoints,
      maxHitPoints: hitPoints,
      armorClass: 11 + getModifier(character.dexterity || 10), // Base 10 + leather armor (1) + dex mod
      speed: 30,
    };

    createCharacterMutation.mutate(completeCharacter);
  };

  return (
    <div className="min-h-screen bg-dm-charcoal text-dm-text">
      {/* Header */}
      <header className="bg-dm-surface border-b border-dm-slate px-6 py-4">
        <div className="flex items-center space-x-4">
          <div className="w-10 h-10 bg-dm-purple rounded-lg flex items-center justify-center">
            <Crown className="text-white text-xl" />
          </div>
          <div>
            <h1 className="text-xl font-cinzel font-semibold text-dm-gold">AI Dungeon Master</h1>
            <p className="text-sm text-gray-400">Create your character</p>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8 max-w-4xl">
        <Card className="bg-dm-surface border-dm-slate">
          <CardHeader>
            <CardTitle className="text-2xl font-cinzel text-dm-gold">Create Your Character</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Basic Info */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="name" className="text-dm-text">Character Name *</Label>
                  <Input
                    id="name"
                    value={character.name || ""}
                    onChange={(e) => setCharacter(prev => ({ ...prev, name: e.target.value }))}
                    className="bg-dm-charcoal border-dm-slate text-dm-text"
                    placeholder="Enter character name"
                  />
                </div>
                <div>
                  <Label htmlFor="race" className="text-dm-text">Race *</Label>
                  <Select onValueChange={(value) => setCharacter(prev => ({ ...prev, race: value }))}>
                    <SelectTrigger className="bg-dm-charcoal border-dm-slate text-dm-text">
                      <SelectValue placeholder="Select race" />
                    </SelectTrigger>
                    <SelectContent className="bg-dm-charcoal border-dm-slate">
                      {races.map(race => (
                        <SelectItem key={race} value={race.toLowerCase()} className="text-dm-text">{race}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="class" className="text-dm-text">Class *</Label>
                  <Select onValueChange={(value) => setCharacter(prev => ({ ...prev, class: value }))}>
                    <SelectTrigger className="bg-dm-charcoal border-dm-slate text-dm-text">
                      <SelectValue placeholder="Select class" />
                    </SelectTrigger>
                    <SelectContent className="bg-dm-charcoal border-dm-slate">
                      {classes.map(cls => (
                        <SelectItem key={cls} value={cls.toLowerCase()} className="text-dm-text">{cls}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Ability Scores */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <Label className="text-lg font-semibold text-dm-gold">Ability Scores</Label>
                  <Button
                    type="button"
                    onClick={rollStats}
                    variant="outline"
                    className="bg-dm-charcoal border-dm-slate text-dm-text hover:bg-dm-slate"
                  >
                    <Dice6 className="w-4 h-4 mr-2" />
                    Roll Stats
                  </Button>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                  {[
                    { key: 'strength', label: 'STR' },
                    { key: 'dexterity', label: 'DEX' },
                    { key: 'constitution', label: 'CON' },
                    { key: 'intelligence', label: 'INT' },
                    { key: 'wisdom', label: 'WIS' },
                    { key: 'charisma', label: 'CHA' }
                  ].map(({ key, label }) => {
                    const score = character[key as keyof typeof character] as number || 10;
                    const modifier = getModifier(score);
                    return (
                      <div key={key} className="text-center">
                        <Label className="text-sm text-gray-400 uppercase">{label}</Label>
                        <Input
                          type="number"
                          min="3"
                          max="18"
                          value={score}
                          onChange={(e) => setCharacter(prev => ({ 
                            ...prev, 
                            [key]: parseInt(e.target.value) || 10 
                          }))}
                          className="bg-dm-charcoal border-dm-slate text-dm-text text-center font-mono text-lg"
                        />
                        <div className="text-xs text-gray-400 mt-1">
                          {modifier >= 0 ? '+' : ''}{modifier}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Submit */}
              <div className="flex justify-center pt-6">
                <Button
                  type="submit"
                  className="bg-dm-purple hover:bg-purple-600 text-white px-8 py-3 text-lg"
                  disabled={createCharacterMutation.isPending}
                >
                  {createCharacterMutation.isPending ? "Creating..." : "Begin Adventure"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
