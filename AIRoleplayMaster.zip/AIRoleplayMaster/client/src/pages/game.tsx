import { useEffect } from "react";
import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Crown, Settings, HelpCircle } from "lucide-react";
import ChatInterface from "@/components/chat-interface";
import CharacterSheet from "@/components/character-sheet";
import MobileDrawer from "@/components/mobile-drawer";
import { useIsMobile } from "@/hooks/use-mobile";

export default function Game() {
  const { characterId } = useParams();
  const isMobile = useIsMobile();

  const { data: character, isLoading: characterLoading } = useQuery({
    queryKey: ["/api/characters", characterId],
    enabled: !!characterId,
  });

  const { data: activeSession } = useQuery({
    queryKey: ["/api/characters", characterId, "active-session"],
    enabled: !!characterId,
  });

  if (characterLoading) {
    return (
      <div className="min-h-screen bg-dm-charcoal text-dm-text flex items-center justify-center">
        <div className="text-center">
          <Crown className="w-12 h-12 text-dm-purple mx-auto mb-4 animate-pulse" />
          <p className="text-lg">Loading your adventure...</p>
        </div>
      </div>
    );
  }

  if (!character) {
    return (
      <div className="min-h-screen bg-dm-charcoal text-dm-text flex items-center justify-center">
        <div className="text-center">
          <p className="text-lg text-dm-red">Character not found</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dm-charcoal text-dm-text">
      {/* Header */}
      <header className="bg-dm-surface border-b border-dm-slate px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 bg-dm-purple rounded-lg flex items-center justify-center">
              <Crown className="text-white text-xl" />
            </div>
            <div>
              <h1 className="text-xl font-cinzel font-semibold text-dm-gold">AI Dungeon Master</h1>
              <p className="text-sm text-gray-400">Epic adventures await</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <button className="p-2 text-gray-400 hover:text-dm-text transition-colors rounded-lg hover:bg-dm-slate">
              <Settings className="w-5 h-5" />
            </button>
            <button className="p-2 text-gray-400 hover:text-dm-text transition-colors rounded-lg hover:bg-dm-slate">
              <HelpCircle className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <div className="flex h-[calc(100vh-80px)] overflow-hidden">
        {/* Chat Interface */}
        <div className="flex-1">
          <ChatInterface character={character} activeSession={activeSession} />
        </div>

        {/* Character Sheet - Desktop Only */}
        {!isMobile && (
          <div className="w-80 bg-dm-surface border-l border-dm-slate">
            <CharacterSheet character={character} />
          </div>
        )}
      </div>

      {/* Mobile Components */}
      {isMobile && (
        <>
          <MobileDrawer character={character} />
          {/* Mobile Bottom Navigation */}
          <div className="fixed bottom-0 inset-x-0 bg-dm-surface border-t border-dm-slate p-4 lg:hidden">
            <div className="flex justify-around">
              <button 
                onClick={() => {
                  const drawer = document.getElementById('mobileCharacterDrawer');
                  drawer?.classList.remove('translate-y-full');
                }}
                className="flex flex-col items-center text-gray-400 hover:text-dm-text transition-colors"
              >
                <Crown className="w-5 h-5 mb-1" />
                <span className="text-xs">Character</span>
              </button>
              <button className="flex flex-col items-center text-gray-400 hover:text-dm-text transition-colors">
                <Settings className="w-5 h-5 mb-1" />
                <span className="text-xs">Settings</span>
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
