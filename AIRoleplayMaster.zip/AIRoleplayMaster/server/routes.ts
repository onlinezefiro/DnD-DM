import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateDMResponse, generateGameIntro } from "./openai";
import { insertCharacterSchema, insertGameSessionSchema, insertMessageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Character routes
  app.get("/api/characters", async (req, res) => {
    try {
      const characters = await storage.getAllCharacters();
      res.json(characters);
    } catch (error) {
      res.status(500).json({ message: "Failed to get characters" });
    }
  });

  app.get("/api/characters/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const character = await storage.getCharacter(id);
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }
      res.json(character);
    } catch (error) {
      res.status(500).json({ message: "Failed to get character" });
    }
  });

  app.post("/api/characters", async (req, res) => {
    try {
      const characterData = insertCharacterSchema.parse(req.body);
      const character = await storage.createCharacter(characterData);
      res.status(201).json(character);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid character data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create character" });
    }
  });

  app.patch("/api/characters/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const character = await storage.updateCharacter(id, updates);
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }
      res.json(character);
    } catch (error) {
      res.status(500).json({ message: "Failed to update character" });
    }
  });

  // Game session routes
  app.get("/api/sessions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const session = await storage.getGameSession(id);
      if (!session) {
        return res.status(404).json({ message: "Game session not found" });
      }
      res.json(session);
    } catch (error) {
      res.status(500).json({ message: "Failed to get game session" });
    }
  });

  app.get("/api/characters/:characterId/active-session", async (req, res) => {
    try {
      const characterId = parseInt(req.params.characterId);
      const session = await storage.getActiveGameSession(characterId);
      res.json(session);
    } catch (error) {
      res.status(500).json({ message: "Failed to get active session" });
    }
  });

  app.post("/api/sessions", async (req, res) => {
    try {
      const sessionData = insertGameSessionSchema.parse(req.body);
      const session = await storage.createGameSession(sessionData);
      res.status(201).json(session);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid session data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create game session" });
    }
  });

  // Message routes
  app.get("/api/sessions/:sessionId/messages", async (req, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      const messages = await storage.getSessionMessages(sessionId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to get messages" });
    }
  });

  app.post("/api/sessions/:sessionId/messages", async (req, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      const messageData = insertMessageSchema.parse({ ...req.body, sessionId });
      const message = await storage.createMessage(messageData);
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid message data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create message" });
    }
  });

  // AI DM response route
  app.post("/api/dm-response", async (req, res) => {
    try {
      const { playerAction, sessionId } = req.body;
      
      if (!playerAction || !sessionId) {
        return res.status(400).json({ message: "Player action and session ID are required" });
      }

      // Get session and character info for context
      const session = await storage.getGameSession(sessionId);
      if (!session) {
        return res.status(404).json({ message: "Game session not found" });
      }

      const character = await storage.getCharacter(session.characterId);
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }

      // Get recent messages for context
      const recentMessages = await storage.getSessionMessages(sessionId);
      const lastFewMessages = recentMessages.slice(-5);
      
      const gameContext = lastFewMessages
        .map(msg => `${msg.sender}: ${msg.content}`)
        .join('\n');

      const characterInfo = `${character.name}, ${character.race} ${character.class} (Level ${character.level})
Stats: STR:${character.strength} DEX:${character.dexterity} CON:${character.constitution} INT:${character.intelligence} WIS:${character.wisdom} CHA:${character.charisma}
HP: ${character.hitPoints}/${character.maxHitPoints} AC: ${character.armorClass}`;

      const dmResponse = await generateDMResponse(playerAction, gameContext, characterInfo);
      
      res.json(dmResponse);
    } catch (error) {
      console.error("DM response error:", error);
      res.status(500).json({ message: error instanceof Error ? error.message : "Failed to generate DM response" });
    }
  });

  // Generate game intro
  app.post("/api/game-intro", async (req, res) => {
    try {
      const { characterName, characterClass, characterRace } = req.body;
      
      if (!characterName || !characterClass || !characterRace) {
        return res.status(400).json({ message: "Character name, class, and race are required" });
      }

      const intro = await generateGameIntro(characterName, characterClass, characterRace);
      res.json({ intro });
    } catch (error) {
      console.error("Game intro error:", error);
      res.status(500).json({ message: error instanceof Error ? error.message : "Failed to generate game introduction" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
