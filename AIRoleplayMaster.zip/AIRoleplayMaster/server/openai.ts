import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface DiceRoll {
  type: string;
  roll: number;
  modifier: number;
  total: number;
  description: string;
}

export interface DMResponse {
  narrative: string;
  diceRolls?: DiceRoll[];
  requiresPlayerInput: boolean;
  actionType: "narrative" | "combat" | "exploration" | "social";
}

export async function generateDMResponse(
  playerAction: string,
  gameContext: string,
  characterInfo: string
): Promise<DMResponse> {
  try {
    const prompt = `You are an expert Dungeon Master running a D&D 5e campaign. 

GAME CONTEXT:
${gameContext}

CHARACTER INFO:
${characterInfo}

PLAYER ACTION:
${playerAction}

As the DM, respond to the player's action with:
1. A vivid, engaging narrative response (2-3 paragraphs)
2. Any necessary dice rolls with results
3. What happens next and if player input is needed

Respond in JSON format with this structure:
{
  "narrative": "Your descriptive response to the player's action",
  "diceRolls": [{"type": "d20", "roll": 15, "modifier": 3, "total": 18, "description": "Perception check"}],
  "requiresPlayerInput": true,
  "actionType": "exploration"
}

Make the story engaging, unexpected, and true to D&D mechanics. Include sensory details and meaningful consequences.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a creative and experienced Dungeon Master who creates immersive D&D experiences. Always respond with valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.8,
      max_tokens: 800
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      narrative: result.narrative || "The DM contemplates your action...",
      diceRolls: result.diceRolls || [],
      requiresPlayerInput: result.requiresPlayerInput !== false,
      actionType: result.actionType || "narrative"
    };
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to generate DM response. The AI seems to be taking a short rest.");
  }
}

export async function generateGameIntro(characterName: string, characterClass: string, characterRace: string): Promise<string> {
  try {
    const prompt = `Create an engaging D&D campaign introduction for a ${characterRace} ${characterClass} named ${characterName}. 

Write a 2-3 paragraph opening that:
- Sets an intriguing scene
- Introduces immediate choices or challenges
- Captures the D&D fantasy atmosphere
- Ends with "What would you like to do?"

Make it immersive and specific to their race/class background.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a masterful Dungeon Master who creates compelling campaign openings."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.8,
      max_tokens: 400
    });

    return response.choices[0].message.content || "Welcome to your adventure!";
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to generate game introduction.");
  }
}
