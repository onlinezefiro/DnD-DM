import { 
  characters, 
  gameSessions, 
  messages,
  type Character, 
  type InsertCharacter,
  type GameSession,
  type InsertGameSession,
  type Message,
  type InsertMessage
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // Character operations
  getCharacter(id: number): Promise<Character | undefined>;
  getAllCharacters(): Promise<Character[]>;
  createCharacter(character: InsertCharacter): Promise<Character>;
  updateCharacter(id: number, updates: Partial<InsertCharacter>): Promise<Character | undefined>;
  
  // Game session operations
  getGameSession(id: number): Promise<GameSession | undefined>;
  getActiveGameSession(characterId: number): Promise<GameSession | undefined>;
  createGameSession(session: InsertGameSession): Promise<GameSession>;
  updateGameSession(id: number, updates: Partial<InsertGameSession>): Promise<GameSession | undefined>;
  
  // Message operations
  getSessionMessages(sessionId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
}

export class MemStorage implements IStorage {
  private characters: Map<number, Character>;
  private gameSessions: Map<number, GameSession>;
  private messages: Map<number, Message>;
  private currentCharacterId: number;
  private currentSessionId: number;
  private currentMessageId: number;

  constructor() {
    this.characters = new Map();
    this.gameSessions = new Map();
    this.messages = new Map();
    this.currentCharacterId = 1;
    this.currentSessionId = 1;
    this.currentMessageId = 1;
  }

  async getCharacter(id: number): Promise<Character | undefined> {
    return this.characters.get(id);
  }

  async getAllCharacters(): Promise<Character[]> {
    return Array.from(this.characters.values());
  }

  async createCharacter(insertCharacter: InsertCharacter): Promise<Character> {
    const id = this.currentCharacterId++;
    const character: Character = {
      ...insertCharacter,
      id,
      level: insertCharacter.level ?? 1,
      speed: insertCharacter.speed ?? 30,
      skills: insertCharacter.skills ?? {},
      equipment: (insertCharacter.equipment ?? []) as Array<{name: string, type: string, equipped: boolean}>,
      inventory: (insertCharacter.inventory ?? []) as Array<{name: string, quantity: number, type: string}>,
      goldPieces: insertCharacter.goldPieces ?? 0,
      createdAt: new Date(),
    };
    this.characters.set(id, character);
    return character;
  }

  async updateCharacter(id: number, updates: Partial<InsertCharacter>): Promise<Character | undefined> {
    const character = this.characters.get(id);
    if (!character) return undefined;
    
    const updatedCharacter = { ...character, ...updates };
    this.characters.set(id, updatedCharacter);
    return updatedCharacter;
  }

  async getGameSession(id: number): Promise<GameSession | undefined> {
    return this.gameSessions.get(id);
  }

  async getActiveGameSession(characterId: number): Promise<GameSession | undefined> {
    return Array.from(this.gameSessions.values()).find(
      session => session.characterId === characterId && session.isActive
    );
  }

  async createGameSession(insertSession: InsertGameSession): Promise<GameSession> {
    const id = this.currentSessionId++;
    const session: GameSession = {
      ...insertSession,
      id,
      isActive: insertSession.isActive ?? true,
      createdAt: new Date(),
    };
    this.gameSessions.set(id, session);
    return session;
  }

  async updateGameSession(id: number, updates: Partial<InsertGameSession>): Promise<GameSession | undefined> {
    const session = this.gameSessions.get(id);
    if (!session) return undefined;
    
    const updatedSession = { ...session, ...updates };
    this.gameSessions.set(id, updatedSession);
    return updatedSession;
  }

  async getSessionMessages(sessionId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => message.sessionId === sessionId)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.currentMessageId++;
    const message: Message = {
      ...insertMessage,
      id,
      messageType: insertMessage.messageType ?? "narrative",
      diceRoll: insertMessage.diceRoll ?? null,
      timestamp: new Date(),
    };
    this.messages.set(id, message);
    return message;
  }
}

export class DatabaseStorage implements IStorage {
  async getCharacter(id: number): Promise<Character | undefined> {
    const [character] = await db.select().from(characters).where(eq(characters.id, id));
    return character || undefined;
  }

  async getAllCharacters(): Promise<Character[]> {
    return await db.select().from(characters);
  }

  async createCharacter(insertCharacter: InsertCharacter): Promise<Character> {
    const [character] = await db
      .insert(characters)
      .values(insertCharacter)
      .returning();
    return character;
  }

  async updateCharacter(id: number, updates: Partial<InsertCharacter>): Promise<Character | undefined> {
    const [character] = await db
      .update(characters)
      .set(updates)
      .where(eq(characters.id, id))
      .returning();
    return character || undefined;
  }

  async getGameSession(id: number): Promise<GameSession | undefined> {
    const [session] = await db.select().from(gameSessions).where(eq(gameSessions.id, id));
    return session || undefined;
  }

  async getActiveGameSession(characterId: number): Promise<GameSession | undefined> {
    const [session] = await db
      .select()
      .from(gameSessions)
      .where(and(
        eq(gameSessions.characterId, characterId),
        eq(gameSessions.isActive, true)
      ));
    return session || undefined;
  }

  async createGameSession(insertSession: InsertGameSession): Promise<GameSession> {
    const [session] = await db
      .insert(gameSessions)
      .values(insertSession)
      .returning();
    return session;
  }

  async updateGameSession(id: number, updates: Partial<InsertGameSession>): Promise<GameSession | undefined> {
    const [session] = await db
      .update(gameSessions)
      .set(updates)
      .where(eq(gameSessions.id, id))
      .returning();
    return session || undefined;
  }

  async getSessionMessages(sessionId: number): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.sessionId, sessionId))
      .orderBy(messages.timestamp);
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await db
      .insert(messages)
      .values(insertMessage)
      .returning();
    return message;
  }
}

export const storage = new DatabaseStorage();
